#pragma once

#pragma pack(push, 1)
GTClass ParticleSystem {
	public:

};
#pragma pack(pop)