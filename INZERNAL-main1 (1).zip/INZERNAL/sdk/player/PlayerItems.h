#pragma once
#include <sdk/sdk.h>

#pragma pack(push, 1)
GTClass PlayerItems {

};
#pragma pack(pop)