#pragma once

class AvatarRenderData {
   public:
    char unk[16]; //has an itemid somewhere
    short clothing[9];
};
