#pragma once

#pragma pack(push, 1)
GTClass EntityComponent {
   public:
    //currently not possible to make anything for this since this needs such a big chunk of (full) proton and needs boost
};
#pragma pack(pop)